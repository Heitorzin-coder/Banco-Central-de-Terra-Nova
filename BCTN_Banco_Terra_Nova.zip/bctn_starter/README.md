# BCTN — Banco Central de Terra Nova

Starter de um banco **fictício** para RPG. A moeda TN$ não tem valor real e o sistema não se conecta ao Pix brasileiro.

## O que já está preparado
- Cadastro e login com Supabase Auth.
- Uma conta TN$ criada automaticamente para cada usuário.
- Chave Pix fictícia exclusiva.
- Transferências entre contas cadastradas, processadas no banco de dados.
- Extrato de movimentações.

## 1. Criar o projeto Supabase
1. Crie um projeto no Supabase.
2. Abra o SQL Editor e execute todo o arquivo `supabase/schema.sql`.
3. Em Project Settings → API, copie a **Project URL** e a chave **anon/public**.
4. Abra `public/config.js` e substitua os valores de exemplo.

A chave `anon/public` pode ficar no navegador quando as políticas RLS estiverem configuradas. **Nunca coloque a `service_role` no site.**

## 2. Testar localmente
Abra a pasta com VS Code e use uma extensão de servidor local (por exemplo, Live Server) para abrir `public/index.html`.

## 3. Publicar para todos
Publique a pasta `public` em um serviço de hospedagem estática (por exemplo, Netlify ou Vercel). Depois, configure no Supabase a URL publicada em Authentication → URL Configuration.

## Regras importantes
- O saldo e as transferências são controlados pelo banco de dados, não pelo JavaScript do navegador.
- Não existe depósito livre para jogadores nesta primeira versão.
- Para adicionar saldo inicial ou criar um painel de tesouraria, faremos uma função administrativa separada, protegida por permissões.
- Use nomes de RPG e senhas que não sejam reutilizados em contas reais.
- Este projeto é um protótipo educacional; antes de uso público, revise segurança, limites e recuperação de conta.
